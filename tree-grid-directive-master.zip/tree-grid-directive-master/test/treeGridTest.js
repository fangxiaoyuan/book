(function () {
    var app, deps;

    deps = ['treeGrid'];

    app = angular.module('treeGridTest', deps);

    app.controller('treeGridController', function ($scope, $timeout) {
        var tree;

        var rawTreeData = [
            {
                "DemographicId": 1,
                "ParentId": null,
                "Name": "1",
                "1": "United States of America",
                "1.1": 9826675,
                "Population": 918212000,
                "TimeZone": "UTC -5 to -10"
            },
            {
                "DemographicId": 2,
                "ParentId": 1,
                "Name": "1.1",
                "1": "The Tech State",
                "1.1": 423970,
                "Population": 38340000,
                "TimeZone": "Pacific Time"
            },
            {
                "DemographicId": 3,
                "ParentId": 2,
                "Name": "1.1.1",
                "1": "The happening city",
                "1.1": 231,
                "Population": 837442,
                "TimeZone": "PST"
            },
            {
                "DemographicId": 4,
                "ParentId": 2,
                "Name": "1.1.2",
                "1": "Disco city",
                "1.1": 503,
                "Population": 3904657,
                "TimeZone": "PST"
            },
            {
                "DemographicId": 5,
                "ParentId": 1,
                "Name": "1.2",
                "1": "Not so cool",
                "1.1": 57914,
                "Population": 12882135,
                "TimeZone": "Central Time Zone"
            },
            {
                "DemographicId": 6,
                "ParentId": 5,
                "Name": "1.2.1",
                "1": "Financial City",
                "1.1": 234,
                "Population": 2695598,
                "TimeZone": "CST"
            },
            {
                "DemographicId": 7,
                "ParentId": 1,
                "Name": "1.3",
                "1": "Rances, Oil & Gas",
                "1.1": 268581,
                "Population": 26448193,
                "TimeZone": "Mountain"
            },
            {
                "DemographicId": 8,
                "ParentId": 1,
                "Name": "1.4",
                "1": "The largest diverse city",
                "1.1": 141300,
                "Population": 19651127,
                "TimeZone": "Eastern Time Zone"
            },
            {
                "DemographicId": 14,
                "ParentId": 8,
                "Name": "1.4.1",
                "1": "Time Square is the place",
                "1.1": 269.403,
                "Population": 0,
                "TimeZone": "EST"
            },
            {
                "DemographicId": 15,
                "ParentId": 14,
                "Name": "1.4.1.1",
                "1": "Manhattan island",
                "1.1": 33.77,
                "Population": 0,
                "TimeZone": "EST"
            },
            {
                "DemographicId": 16,
                "ParentId": 14,
                "Name": "1.4.1.2",
                "1": "Time Square for new year",
                "1.1": 269.40,
                "Population": 0,
                "TimeZone": "EST"
            },
            {
                "DemographicId": 17,
                "ParentId": 8,
                "Name": "1.4.1",
                "1": "Close to Canada",
                "1.1": 65.7,
                "Population": 0,
                "TimeZone": "EST"
            },
            {
                "DemographicId": 18,
                "ParentId": 8,
                "Name": "1.4.2",
                "1": "Harbour to Atlantic",
                "1.1": 362.9,
                "Population": 0,
                "TimeZone": "EST"
            },
            {
                "DemographicId": 51,
                "ParentId": 1,
                "Name": "1.5",
                "1": "All_Other demographics",
                "1.1": 0,
                "Population": 0,
                "TimeZone": 0
            },
            {
                "DemographicId": 201,
                "ParentId": null,
                "Name": "2",
                "1": "Hydrabad tech city",
                "1.1": 5566.9,
                "Population": 718212000,
                "TimeZone": "IST"
            },
            {
                "DemographicId": 301,
                "ParentId": null,
                "Name": "3",
                "1": "Country of love",
                "1.1": 5566.78,
                "Population": 718212004,
                "TimeZone": "BST"
            }
        ];


        var myTreeData = getTree(rawTreeData, 'DemographicId', 'ParentId');

        $scope.tree_data = myTreeData;
        $scope.my_tree = tree = {};
        $scope.expanding_property = {
            field: "Name",
            displayName: "Demographic Name",
            sortable: true,
            filterable: true,
            cellTemplate: "<i>{{row.branch[expandingProperty.field]}}</i>"
        };
        $scope.col_defs = [
            {
                field: "1",
                sortable: true,
                sortingType: "string",
                display:true,
                child:true,
                id:1,
                parentId:0,
            },
            {
                field: "1.1",
                sortable: true,
                sortingType: "number",
                filterable: true,
                display:false,
                parentId:1,
                id:2
            },
            {
                field: "1.1.1",
                sortable: true,
                sortingType: "number",
                display:false,
                id:3,
                parentId:2,
            },{
                field: "2",
                sortable: true,
                sortingType: "number",
                display:true,
                id:4,
                parentId:0
            },
            {
                field: "2.1",
                sortable: true,
                sortingType: "number",
                display:false,
                id:5,
                parentId:4
            },
            /*{
                field: "TimeZone",
                displayName: "Time Zone",
                cellTemplate: "<strong>{{row.branch[col.field]}}</strong>",
                display:false,
                id:6,
                parentId:0
            },*/
        ];
        $scope.my_tree_handler = function (branch) {
            console.log('you clicked on', branch)
        }

        function getTree(data, primaryIdName, parentIdName) {
            if (!data || data.length == 0 || !primaryIdName || !parentIdName)
                return [];

            var tree = [],
                rootIds = [],
                item = data[0],
                primaryKey = item[primaryIdName],
                treeObjs = {},
                parentId,
                parent,
                len = data.length,
                i = 0;

            while (i < len) {
                item = data[i++];
                primaryKey = item[primaryIdName];
                treeObjs[primaryKey] = item;
                parentId = item[parentIdName];

                if (parentId) {
                    parent = treeObjs[parentId];

                    if (parent.children) {
                        parent.children.push(item);
                    } else {
                        parent.children = [item];
                    }
                } else {
                    rootIds.push(primaryKey);
                }
            }

            for (var i = 0; i < rootIds.length; i++) {
                tree.push(treeObjs[rootIds[i]]);
            }
            ;

            return tree;
        }

    });

}).call(this);
